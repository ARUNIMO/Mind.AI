# Amazon Clone

### Tech : HTML, CSS