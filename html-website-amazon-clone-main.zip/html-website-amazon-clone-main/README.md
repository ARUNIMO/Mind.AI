# html-website-amazon-clone
we make the amazon clone website using html in the guidance of AccioJob 
